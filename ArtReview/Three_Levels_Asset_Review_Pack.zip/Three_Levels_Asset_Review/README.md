# 三关资产验收包

共 33 件。这里的资产作为独立文件供审核与后续挑选。现有 Unity 工程保持原场景版本。

## 怎么看

- Three_Levels_Asset_Library.blend 是完整可编辑的 Blender 5 资产库，已打包 Blender 所需贴图。
- Blender 中按入口与路径、圆形展厅、雕塑大厅、可选装饰分组。摆放的是资产集合实例，原始集合可在 Asset Browser 中选择 Current File 后查看。模型默认按米制。
- Review 图片逐件展示模型。Asset_Catalog.json 对照名称、包围盒、网格数量和放置说明。
- FBX 目录一件一个文件，倒角已经包含在导出的渲染几何里。六个代表性 FBX 已在 Blender 中回读，核对网格数量和尺寸。

## 后续接到 Unity

导入需要替换的 FBX 与 Textures，再用工程当前的 URP 材质配置。FBX 负责几何、层级和 UV。确认 Unity 工程的导入单位和朝向。房间地面、门洞和雕塑沿用原设计尺度，接入时复核碰撞和玩家净空。

- BaseColor 为颜色贴图。Normal 按 Normal Map 导入。URP_Mask 关闭 sRGB 后用于 Metallic 和 Occlusion，共用的 R 通道是金属度，G 通道是遮蔽，A 通道是光滑度。另提供 Roughness 与 Metallic 原贴图。
- L01_Slab 的原点在齐平的行走面。A/B/C 可以轮换，实际踩踏碰撞继续用比赛工程的等高碰撞。
- L01_Reveal 的三种标记是独立的可见层，适合接入第一关已有的面具显隐逻辑。
- 圆厅扇区以半径 13 米的内壁中点为原点，每个扇区覆盖 30 度。换扇区时围绕房间圆心摆位。
- 守卫的脚底中心是原点，正面为 Blender +Y。头、手臂、腿和胸前嵌件分网格保留。
- L03_TeleportRecess 里保留 Teleport_Trigger_Reference 空对象。游戏行为由比赛工程对接。
- 壁灯外壳和低石座是可选装饰，摆进场景时检查通行净空。展品用三个尺寸占位，具体展品待定。

材料原图是为这套资产程序化生成的。验收图使用 Blender 的工作室灯光，具体灯光、碰撞与头显效果留到逐件导入后确认。
