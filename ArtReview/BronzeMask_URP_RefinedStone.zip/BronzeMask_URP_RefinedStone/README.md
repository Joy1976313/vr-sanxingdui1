# 三关 Unity URP 工程 · 石材精修版

Unity 6000.3.27f2 / URP 17.3.0。解压后用 Unity Hub 添加工程根目录。
打开 Assets/BronzeMask_ArtSample/Scenes/L01_L02_L03_RefinedFloor.unity，默认第一关入口眼高相机。

第一关 03 Limestone floor 含 77 个等高石板 Prefab 实例。每块只有一个渲染网格与盒碰撞。
RefinedStone 文件夹含 PF_Limestone_Slab、三个倒角形体变体、URP Lit 材质、基色贴图、切线空间法线以及合并遮蔽和光滑度的贴图。
形体和旋转按格号均匀变化。所有候选块共用材质。04 MASK ON 根对象可手动切换路线。
第二、第三关沿用三关美术版，传送参考点位于第三关 Exit portal | Teleport handoff。

材质贴图为本工程程序化生成。表面特征参考 Poly Haven 的 Pavement 01（https://polyhaven.com/a/pavement_01），打包通道按 Unity URP 手册配置。
已重新打开保存后的场景检查 77 块的等高碰撞和运行画面。设备端的纹理闪烁、远距离辨识及性能待头显实测。
